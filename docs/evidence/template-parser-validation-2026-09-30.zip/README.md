# Table-free parser evidence capsule

Start with `validation-report.md`. This pack is a compact release receipt, not
the complete raw benchmark corpus. Read the caveats with the results.

Run `python3 verify_capsule.py` after extraction. It verifies every included
file checksum and independently recomputes reported medians and percentage
changes from the saved process-level summaries. This does not substitute for
the separate audit of the omitted raw token timings.

`raw-output-index.json` lists the 256 original timing files by lab-relative
path, SHA-256 and size. Their approximately 270 MB of raw data is not included.
`source-provenance.json` pins the runtime source, dependencies and inputs.
`parser-sections.csv` contains 84 fresh, final-library byte measurements.
`adverse-case-flags.json` intentionally retains the unfavorable observations.

The implementation is opt-in, not a declaration of unconditional superiority.
No default switch, main merge, package version, or registry publication is
implied by these evidence files. All latency measurements retain cold and the
first warm replay. See the report for aggregation and independence limits.
