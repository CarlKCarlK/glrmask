from pathlib import Path
import hashlib,json,math,statistics
D=Path(__file__).resolve().parent
manifest=json.loads((D/'checksums.json').read_text())
for name,digest in manifest.items():
 assert hashlib.sha256((D/name).read_bytes()).hexdigest()==digest,name
data=json.loads((D/'paired-process-summaries.json').read_text())
checked=0
for condition in data['conditions']:
 for comparison in condition['comparisons'].values():
  for phase in comparison.values():
   for metric in phase.values():
    for cell in metric.values():
     a=statistics.median(cell['baseline_process_values_ns'])
     b=statistics.median(cell['candidate_process_values_ns'])
     for actual,expected in [(a,cell['baseline_ns']),(b,cell['candidate_ns']),(100*(b/a-1),cell['change_pct'])]:
      assert math.isclose(actual,expected,rel_tol=1e-11,abs_tol=1e-7)
     checked+=1
assert checked==2400,checked
print('PASS:',len(manifest),'included file checksums and',checked,'paired cells')
print('Raw token samples are not included; this does not rerun their audit.')
